#ifndef IOMEM_H
#define IOMEM_H

#define SYSTEM_RAM		"System RAM\n"
#define SYSTEM_RAM_BOOT		"System RAM (boot alias)\n"
#define CRASH_KERNEL		"Crash kernel\n"
#define CRASH_KERNEL_BOOT	"Crash kernel (boot alias)\n"

#endif
