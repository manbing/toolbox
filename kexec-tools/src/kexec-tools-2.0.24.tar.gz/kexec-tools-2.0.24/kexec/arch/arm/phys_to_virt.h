#ifndef PHYS_TO_VIRT_H
#define PHYS_TO_VIRT_H

#include <stdint.h>

extern uint64_t phys_offset;

#endif
