#ifndef IOMEM_H
#define IOMEM_H

#define SYSTEM_RAM		"System RAM\n"
#define KERNEL_CODE		"Kernel code\n"
#define KERNEL_DATA		"Kernel data\n"
#define CRASH_KERNEL		"Crash kernel\n"
#define IOMEM_RESERVED		"reserved\n"

#endif
