#ifndef PURGATORY_MIPSEL_H
#define PURGATORY_MIPSEL_H

/* nothing yet */

#endif /* PURGATORY_MIPSEL_H */
